+++
id = 'angular-code'
title = 'Angular 17 Code Mode Rules (SOTA Edition)'
scope = 'code-mode'
target_audience = 'Code Mode Agent'
status = 'active'
+++

# Angular 17 Code Mode Rules (SOTA Edition)

> These SOTA-aligned directives govern all code generation, modification, and refactoring tasks. They are designed to produce exceptionally clean, performant, and secure Angular code. Strict adherence is required.

## 1. The Golden Rule: Codebase Consistency
- **Analyze Before You Code**: Before implementing any feature or fix, inspect the surrounding files and directories. Your primary goal is to maintain the established patterns of the existing codebase.
- **Mirror Existing Patterns**: New components, services, and logic must conform to the architectural and stylistic conventions of the module you are working in. If a feature uses a specific state management pattern, follow it. If files are structured in a certain way, adhere to that structure.
- **One Voice**: The entire codebase should look like it was written by a single, disciplined developer. Consistency overrides personal preference.

## 2. RxJS & Asynchronous Patterning
1.  **Eliminate Nested Subscriptions**: Never nest a `.subscribe()` call within another. This anti-pattern leads to memory leaks and unpredictable race conditions. Instead, use higher-order mapping operators.
    -   `switchMap`: For cancellation (e.g., HTTP requests from changing inputs).
    -   `mergeMap`: For concurrent inner observables.
    -   `concatMap`: For sequential execution.
    -   `exhaustMap`: To ignore new observables while the current one is active.

    ```ts
    // ✅ Correct: Using a higher-order mapping operator
    this.searchQuery$.pipe(
      switchMap(query => this.apiService.getData(query))
    ).subscribe(results => this.results.set(results));
    ```

2.  **Automate Unsubscriptions**: Manually managing subscriptions is error-prone. Use the `takeUntilDestroyed()` operator from `@angular/core/rxjs-interop` to tie an observable's lifecycle to its component.

    ```ts
    import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

    // ... inside a component, service, or directive class
    constructor() {
      this.someObservable$.pipe(
        takeUntilDestroyed()
      ).subscribe(...);
    }
    ```

## 3. Template & Rendering Logic
-   **Mandatory `trackBy` for `@for` Loops**: Every `@for` block that iterates over a collection of objects **must** include a `track` function. This provides a unique identifier for each item, allowing Angular to avoid re-rendering the entire DOM list on data changes.

    ```html
    <!-- component.html -->
    <li @for="let user of users(); track user.id">
      {{ user.name }}
    </li>
    ```
    ```ts
    // component.ts
    // The track function itself is now implicitly user.id
    ```

-   **Strategic Use of `@defer`**: Employ `@defer` blocks to lazily render components that are not immediately visible or are computationally expensive. This significantly improves Largest Contentful Paint (LCP) and Time to Interactive (TTI).

## 4. DOM Abstraction
-   **No Direct DOM Manipulation**: Direct interaction with the DOM (e.g., `document`, `ElementRef.nativeElement`) is strictly prohibited. It bypasses Angular's security mechanisms and creates tight coupling with the rendering platform. Use `Renderer2` or data binding instead.

## 5. Testing & Verification
-   **Test-Driven Development (TDD) as the Standard**: Write unit tests *before* or *concurrently with* new code. Every component, service, and utility must have a corresponding `.spec.ts` file.
-   **AAA Pattern**: Structure all tests using the Arrange-Act-Assert pattern for clarity.
-   **Coverage Mandate**: New or refactored code must achieve a minimum of **90% test coverage**.

## 6. Angular Material & Component-Driven Development (CDK)

-   **Component Harnesses for Testing**: All tests for components that use Angular Material **must** use Component Test Harnesses. This makes tests more robust and less brittle by decoupling them from internal DOM structure.

    ```ts
    // ✅ Correct: Using a harness
    const button = await loader.getHarness(MatButtonHarness.with({text: 'Submit'}));
    expect(await button.isDisabled()).toBe(false);
    await button.click();

    // ❌ Incorrect: Using querySelector
    const buttonElement = fixture.nativeElement.querySelector('button');
    ```

-   **Import Only What You Use**: When using Material components in a standalone component, only import the specific modules needed (e.g., `MatButtonModule`, `MatInputModule`). Avoid importing legacy "all-in-one" modules.

-   **Accessibility (`a11y`) First**: Use the tools from `@angular/cdk/a11y` to ensure interfaces are accessible.
    -   Use `CdkTrapFocus` in modals and drawers.
    -   Use `LiveAnnouncer` for dynamic screen reader announcements.
    -   Ensure all custom controls are fully keyboard-navigable.

-   **Theming**: Component-specific style adjustments **must** be done in the component's encapsulated SCSS file using Material's Sass mixins and CSS variables. Avoid global style overrides.

    ```scss
    @use '@angular/material' as mat;

    :host {
      // Use theme variables for custom components
      background-color: var(--mat-app-background-color);
      color: var(--mat-app-text-color);
    }
    ```

## 7. Linting, Styling & Naming Conventions
-   **Strict Linting**: The codebase must remain 100% compliant with our shared ESLint configuration (`@angular-eslint/recommended`, `eslint-plugin-rxjs`, etc.). Run `eslint --fix` on all changed files before committing.
-   **SCSS Best Practices**:
    -   Use the **BEM (Block, Element, Modifier)** methodology for clear, scoped class names.
    -   Use CSS Custom Properties (variables) for all theme-related values (colors, spacing, fonts).
    -   Avoid `::ng-deep` and other view encapsulation-piercing selectors.
-   **File Naming**: Adhere to the `feature.type.ts` kebab-case convention.
    -   `invoice-table.component.ts`
    -   `auth-state.service.ts`
    -   `is-admin.directive.ts`
-   **Symbol Naming**:
    -   `lowerCamelCase` for methods and properties.
    -   `UpperCamelCase` for classes, interfaces, enums, and type aliases.
    -   `$` suffix for properties that are Observables (e.g., `users$`).
    -   `SCREAMING_SNAKE_CASE` for compile-time constants.

## 8. Security Imperatives
-   **No Raw HTML Injection**: Never bind to `[innerHTML]` with un-sanitized data. Use Angular's built-in sanitization or, where absolutely necessary, `DomSanitizer` with extreme caution.
-   **No Hardcoded Secrets**: Credentials, API keys, or tokens must never be present in source code. Load them from environment variables or a secure vault service.

## 9. Error Handling
-   When an error is detected (e.g., failed test, linting issue), first attempt to auto-correct it.
-   If auto-correction is not possible, halt execution and **flag the issue for human review**, detailing the error, the attempted fix, and the file/line number.

---

_This is the operational playbook for writing world-class Angular code. Failure to comply will break the build. Repeated violations will require architectural review._
