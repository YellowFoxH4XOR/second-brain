+++
id = 'python-code'
title = 'Python Code Mode Rules (SOTA Edition)'
scope = 'code-mode'
target_audience = 'Code Mode Agent'
status = 'active'
+++

# Python Code Mode Rules (SOTA Edition)

> These SOTA-aligned directives govern all Python code generation and refactoring. They are designed to produce exceptionally clean, idiomatic, performant, and secure code.

## 1. The Golden Rule: Codebase Consistency
- **Analyze Before You Code**: Before implementing any feature or fix, inspect the surrounding files and directories. Your primary goal is to maintain the established patterns of the existing codebase.
- **Mirror Existing Patterns**: New functions, classes, and modules must conform to the architectural and stylistic conventions of the package you are working in. If a module uses a specific design pattern (e.g., repository, factory), follow it.
- **One Voice**: The entire codebase should look like it was written by a single, disciplined developer. Consistency overrides personal preference.

## 2. Code Style & Idioms

-   **Formatting**: All code **must** be formatted with **Black** using its default configuration. No exceptions.
-   **Linting**: All code **must** pass linting with **Ruff** using the configured rule set (`pyproject.toml`). Address or explicitly ignore (`# noqa`) every reported violation.
-   **Imports**: Imports **must** be sorted automatically by `isort` (integrated into Ruff). Follow this structure:
    1.  Standard library
    2.  Third-party libraries
    3.  First-party/local application libraries

-   **Naming Conventions**:
    -   `snake_case` for variables, functions, and methods.
    -   `PascalCase` for classes.
    -   `CONSTANT_CASE` for constants.
    -   `_` for unused variables.
    -   `_` prefix for "private" attributes/methods (by convention).

-   **Docstrings**: All modules, classes, and public functions/methods **must** have a Google-style docstring.

    ```python
    def my_function(arg1: str, arg2: int) -> bool:
        """This is a short summary of the function.

        This is a more detailed description of its behavior, inputs,
        and outputs.

        Args:
            arg1: Description of the first argument.
            arg2: Description of the second argument.

        Returns:
            True if successful, False otherwise.
        """
        # ... function body ...
    ```

## 3. Typing

-   **Comprehensive Type Hinting**: All function signatures (arguments and return values) and variable declarations **must** include type hints.
-   **Use Modern Types**: Prefer types from the `typing` module, such as `Literal`, `Final`, and `TypeAlias`. Use `|` for unions (Python 3.10+) instead of `Union`.
-   **No `Any`**: The `typing.Any` type is forbidden. Use `object` or `unknown` from a library if a type is truly unknown, or generics for flexibility.

## 4. Idiomatic Python

-   **Comprehensions**: Use list, dict, and set comprehensions instead of manual `for` loops for creating collections.
-   **Context Managers**: Use the `with` statement for any resource that needs to be managed (files, database connections, locks).
-   **Generators for Large Data**: Use generator functions (`yield`) and generator expressions to process large datasets lazily, minimizing memory consumption.
-   **Exception Handling**: Be specific. Catch concrete exceptions (`except ValueError:`) instead of generic ones (`except Exception:`).

## 5. Testing

-   **Fixtures over Setup/Teardown**: Use `pytest` fixtures for setting up test states. They are more modular and reusable than `setUp`/`tearDown` methods.
-   **Parametrization**: Use `@pytest.mark.parametrize` to run the same test with different inputs, reducing code duplication.
-   **Mocks**: Use `unittest.mock` (or `pytest-mock`) for mocking dependencies. Ensure mocks are specific and don't hide integration issues.

## 6. Security Imperatives (Code-Level)

-   **No `eval()` or `exec()`**: Never use `eval()` or `exec()` with untrusted input.
-   **No `pickle` with Untrusted Data**: Do not deserialize data from untrusted sources using `pickle`, as it can lead to arbitrary code execution. Use safer formats like JSON.
-   **Subprocess Security**: When using `subprocess`, always use `shell=False` or ensure any shell commands are constructed with `shlex.quote()` to prevent shell injection.
-   **Assert for Internal Logic Only**: Do not use `assert` statements to validate input data from external sources; they are disabled in production (`-O` flag). Use explicit checks and raise exceptions.

## 7. FastAPI Best Practices

-   **Async By Default**: All path operation functions that perform I/O (e.g., database calls, external API requests) **must** be defined with `async def` to ensure non-blocking execution.

-   **Dependency Injection**: **Must** use FastAPI's `Depends` system to manage dependencies like database sessions or service classes. This improves testability and follows the "Inversion of Control" principle.

    ```python
    from fastapi import Depends, FastAPI
    from sqlalchemy.orm import Session
    from .dependencies import get_db_session

    app = FastAPI()

    @app.get("/items/")
    async def read_items(db: Session = Depends(get_db_session)):
        # Use the injected database session
        return db.query(Item).all()
    ```

-   **Structured Routing**: For any non-trivial service, **must** use `APIRouter` to organize path operations into separate modules, typically grouped by feature or domain. This keeps the main application file clean.

-   **Background Tasks for Non-Blocking Operations**: For operations that should not block the HTTP response (e.g., sending an email notification, processing a webhook), **must** use `BackgroundTasks`.

    ```python
    from fastapi import BackgroundTasks, FastAPI

    def write_notification(email: str, message: str):
        # ... logic to send email ...

    @app.post("/contact/")
    async def send_contact_message(email: str, message: str, background_tasks: BackgroundTasks):
        background_tasks.add_task(write_notification, email, message="Your message was received.")
        return {"status": "Message sent in the background"}
    ```

-   **Precise Status Codes**: Return specific HTTP status codes. For instance, use `status.HTTP_201_CREATED` on successful resource creation instead of relying on the default `200 OK`.

-   **Pydantic Models for API I/O**: All request bodies and responses **must** be defined with Pydantic models for strict data validation and to generate accurate OpenAPI schemas automatically.

## 8. Error Handling & Auto-Correction

-   Upon detecting a linting or type error, attempt to auto-correct it using `ruff --fix` and `black`.
-   If auto-correction fails, halt and **flag the issue for human review**, providing the tool's output and file context.

---

_This playbook ensures all Python code aligns with Google Fellow-level standards of quality and security. Non-compliance will fail the CI build._ 