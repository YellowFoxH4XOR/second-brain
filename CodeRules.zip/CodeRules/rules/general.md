+++
id = 'general-task-management'
title = 'General Task Management Protocol'
scope = 'workspace'
target_audience = 'All Agents'
status = 'active'
+++

# General Task Management Protocol

> To ensure clarity, traceability, and alignment on all development work, every new task must be formally documented in the `task.md` file **before** any implementation begins. This is a non-negotiable first step.

## Task Documentation Procedure

Before writing any code for a new request, you are required to update the root `task.md` file.

### 1. Determine the Task ID
- Review `task.md` to find the highest existing `Task ID`.
- The new `Task ID` **must** be the previous highest ID incremented by one.
- If the file is empty or no tasks exist, start with `Task ID 1`.

### 2. Add the Task Entry
- Append a new task entry to `task.md` using the exact format below.

### 3. Required Format
Use the following Markdown template for every new task entry:

```text
## Task {ID}

**Description**:
{A clear and concise explanation of the requested work.}

**Acceptance Criteria**:
- {A specific, verifiable criterion for completion.}
- {Another specific, verifiable criterion.}

**Story Points**: {A number representing estimated effort, e.g., 1, 2, 3, 5, 8}

**Status**: {In Progress | Done}
```

### 4. Status
- Set the initial `Status` to **In Progress** when you create the entry.
- Update the `Status` to **Done** only upon full completion of all acceptance criteria.

**Instruction:**
**Do not proceed to any coding activities until `task.md` has been properly updated according to these rules for the current task.**

## Universal Software Development Principles (The Golden Rules)

> These principles are language-agnostic and form the foundation of our engineering culture. They apply to every line of code written and every system designed.

-   **Write Clean, Readable Code**: Code is read far more often than it is written. Prioritize clarity and simplicity over cleverness. The next developer (who might be you) should be able to understand your code's intent without a deep-dive investigation.

-   **YAGNI (You Ain't Gonna Need It)**: Do not implement functionality until it is necessary. Avoid speculative features and premature optimization, as they add complexity and maintenance overhead for no immediate value.

-   **DRY (Don't Repeat Yourself)**: Every piece of knowledge must have a single, unambiguous, authoritative representation within a system. If you find yourself copying and pasting code, abstract it into a reusable function, class, or module.

-   **The Boy Scout Rule**: Always leave the codebase cleaner than you found it. Whether it's fixing a typo, improving a variable name, or refactoring a small piece of logic, continuous small improvements prevent technical debt from accumulating.

-   **Commit Atomically and Descriptively**: Each commit should represent a single, logical change. Commit messages must be clear and follow the Conventional Commits specification. This provides a clean, understandable project history.

-   **Own Your Work, End-to-End**: Your responsibility does not end when the code is merged. It extends to deployment, monitoring, and addressing any production issues that arise from your changes. 