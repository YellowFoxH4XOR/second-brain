+++
id = 'angular-ws'
title = 'Angular 17 Workspace Rules (SOTA Edition)'
scope = 'workspace'
target_audience = 'All Agents'
status = 'active'
+++

# Angular 17 Workspace Rules (SOTA Edition)

> These guidelines define the **State-of-the-Art (SOTA)** standards for this enterprise monorepo. SOTA refers to techniques and methods that represent the peak of development, ensuring our architecture is performant, scalable, secure, and maintainable. Adherence is mandatory.

## 1. Core Architectural Principles

- **Standalone is the Standard**: All new components, directives, and pipes **must** be `standalone: true`. This approach reduces boilerplate, simplifies the component's dependency graph, and improves tree-shakability. `NgModule` is considered a legacy pattern, reserved exclusively for integrating third-party libraries that do not yet support standalone APIs.

- **Feature-Driven Organization**: The codebase **must** be organized by feature, not by file type. This colocation improves modularity and makes features easier to find, develop, and lazy-load.

  ```
  // ✅ Correct: Feature-based
  src/app/features/
  └── invoice-management/
      ├── components/
      │   ├── invoice-table.component.ts
      │   └── invoice-editor.component.ts
      ├── services/
      │   └── invoice-api.service.ts
      └── models/
          └── invoice.model.ts

  // ❌ Incorrect: Type-based
  src/app/
  ├── components/
  ├── services/
  └── models/
  ```

- **Strict File & Function Sizing**:
  - **Files**: Must not exceed **400 lines**.
  - **Functions/Methods**: Must not exceed **75 lines**.
  - _Rationale_: This enforces the Single Responsibility Principle, improves readability, and simplifies unit testing.

## 2. State Management & Data Flow

- **Signals as the Default for UI State**: Angular Signals are the preferred mechanism for managing component-level and local service state. Use `signal()`, `computed()`, `effect()`, `input()`, and `output()` to create reactive, glitch-free, and performant UIs. This avoids the overhead of `zone.js` for many scenarios.

- **RxJS for Complex Asynchronous Operations**: For complex asynchronous chains (e.g., multi-step API calls, real-time data streams), use RxJS. However, bridge back to Signals in the component layer using `toSignal`.

- **Global State Management**: For global state shared across many features, use a dedicated state management library that supports Signals, such as NgRx SignalStore or Elf.

## 3. Performance & Change Detection

- **OnPush Everywhere**: All components **must** use `changeDetection: ChangeDetectionStrategy.OnPush`. This strategy prevents unnecessary change detection cycles, dramatically improving rendering performance.

  ```ts
  @Component({
    standalone: true,
    // ...
    changeDetection: ChangeDetectionStrategy.OnPush,
  })
  export class MyComponent {}
  ```

- **Native Control Flow**: The built-in `@if`, `@for`, and `@switch` blocks are mandatory. They are faster than legacy `*ngIf`/`*ngFor` directives and offer better type narrowing.

- **Image Optimization**: All static `<img>` tags **must** be replaced with the `NgOptimizedImage` directive (`ngSrc`) to enable automatic lazy loading, `srcset` generation, and performance pre-connect hints.

- **Lazy Loading & Deferrable Views**:
  - All feature routes **must** be lazy-loaded using `loadComponent`.
  - Use `@defer` blocks to defer the loading of non-critical or below-the-fold components, improving initial page load times (LCP).

## 4. Code Quality & Typing

- **Strict TypeScript Enforcement**: The `tsconfig.json` **must** have `strict: true` enabled. The `any` type is forbidden. Use `unknown` with appropriate type guards or `zod` for runtime validation of external data (e.g., API responses).

## 5. UI & Component Library

- **Angular Material as the Standard**: **Angular Material** is the exclusive UI component library for this workspace. All new user interfaces **must** be built using its components to ensure visual consistency, accessibility, and maintainability.
- **Centralized Theming**: A central Material theme (`src/theme.scss`) defines all color palettes and typography. Components **must not** override Material styles with global CSS. Customizations must be achieved by extending the theme using official Sass APIs.
- **Iconography**: Use the `MatIcon` component with a registered SVG icon set. Do not use font-based icons.

## 6. Security Posture

- **Proactive Threat Mitigation**: Every code change must be written defensively. Routinely flag and fix security anti-patterns, including potential XSS vectors, insecure API calls, and information disclosure risks.

---

_These rules define our commitment to engineering excellence. Exceptions are rare and require formal approval from the architecture review board._
