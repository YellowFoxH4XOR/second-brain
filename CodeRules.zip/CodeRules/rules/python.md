+++
id = 'python-ws'
title = 'Python Workspace Rules (SOTA Edition)'
scope = 'workspace'
target_audience = 'All Agents'
status = 'active'
+++

# Python Workspace Rules (SOTA Edition)

> These guidelines define the **State-of-the-Art (SOTA)** standards for all Python projects. SOTA represents the peak of development, ensuring our architecture is robust, scalable, and secure. Adherence is mandatory.

## 1. Core Architectural Principles

- **Project Structure & Packaging**: All projects **must** use a modern `src` layout and be managed with a `pyproject.toml` file. This standardizes package structure and build isolation.

  ```
  project-root/
  ├── src/
  │   └── my_package/
  │       ├── __init__.py
  │       └── main.py
  ├── tests/
  │   └── test_main.py
  ├── pyproject.toml
  └── README.md
  ```

- **Dependency Management**: **Poetry** is the standard for dependency management and packaging.
  - All dependencies **must** be declared in `pyproject.toml`.
  - The `poetry.lock` file **must** be committed to the repository to ensure deterministic builds.
  - Avoid `requirements.txt` for anything other than specific deployment scenarios.

- **Environment Isolation**: All development **must** occur within a dedicated virtual environment (e.g., via `poetry shell`). Production deployments **must** be containerized using Docker.

## 2. Code Quality & Modernization

- **Python Version**: All projects **must** target **Python 3.11** or newer to leverage performance improvements and modern language features.
- **Strict Static Typing**: All new code **must** be fully type-hinted and pass `mypy --strict` validation. The use of `# type: ignore` is forbidden without an accompanying, approved justification.
- **Automated Formatting & Linting**: Code **must** be formatted with **Black** and linted with **Ruff**. These checks are non-negotiable and enforced via pre-commit hooks.

## 3. API & Service Design

- **API Framework**: **FastAPI** is the default framework for building synchronous and asynchronous web APIs due to its performance and automatic OpenAPI/JSON Schema generation.
- **Data Validation**: **Pydantic** **must** be used for all data validation, serialization, and deserialization at system boundaries (e.g., API requests/responses, configuration). This ensures data integrity and self-documenting models.

## 4. Performance & Concurrency

- **Default to `asyncio`**: For services involving I/O-bound operations (network requests, database calls), `asyncio` is the preferred concurrency model.
- **Use `multiprocessing` for CPU-Bound Work**: For heavy computational tasks that are not I/O-bound, use the `multiprocessing` module to bypass the Global Interpreter Lock (GIL).
- **Profile Before Optimizing**: Do not engage in premature optimization. Use profilers like `cProfile` or `py-spy` to identify true bottlenecks before refactoring.

## 5. Testing & Validation

- **Testing Framework**: **pytest** is the exclusive framework for all tests.
- **Coverage Standard**: All new modules must achieve a minimum of **90% unit test coverage**, enforced by CI pipeline checks using `pytest-cov`.
- **AAA Pattern**: Structure tests using the **Arrange-Act-Assert** pattern for maximum readability and maintainability.

## 6. Security Posture

- **Automated Vulnerability Scanning**: CI pipelines **must** integrate dependency vulnerability scanning using tools like `poetry check` and `pip-audit`.
- **Proactive Threat Mitigation**: Always be vigilant for security anti-patterns. Flag and remediate insecure practices such as deserializing untrusted data, potential command injections, or improper handling of secrets.

---

_These rules define our commitment to world-class engineering. Exceptions require formal approval from the architecture review board._ 